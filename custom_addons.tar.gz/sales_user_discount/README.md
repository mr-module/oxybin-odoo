Sales User Discount in Sales Quotation and Sales Order
------------------------------------------------------

User wise discount is providing the easiness in the sales system to finalized some level of discount.

The module gives the functionality to define user wise discount in particular customer. So, while creating the Sales Quotation or Sales Order in the order line it will apply the defined discount for the customer which was finalized as per the particular user.


