POS debranding
==============

Removes references to odoo.com:

1. Deletes odoo logo
2. Replaces POS title

Tested on Odoo 9.0 04c6ee54d86013bc2995778f62074115c1bd9ed3
