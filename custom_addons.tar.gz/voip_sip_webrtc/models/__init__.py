# -*- coding: utf-8 -*-

from . import voip_voip
from . import res_users
from . import res_partner
from . import voip_call
from . import voip_ringtone
from . import voip_settings
from . import voip_server
from . import voip_account
from . import voip_account_action
from . import voip_message_compose
from . import voip_codec
from . import voip_call_template
from . import ir_actions_server
from . import voip_call_template_preview
from . import voip_media
from . import voip_message_template